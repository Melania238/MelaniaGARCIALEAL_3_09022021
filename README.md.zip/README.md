La première version du site OhMyFood

Ohmyfood! est une entreprise de commande de repas en ligne. Et permet aux utilisateurs de composer leur propre menu et réduire leur temps d’attente dans les restaurants car leur menu est préparé à l’avance. Plus de perte de temps à consulter la carte

Liens vers le site githubPage: https://melania238.github.io/MelaniaGARCIALEAL_3_09022021/

Liens vers le dépôt Github: https://github.com/Melania238/MelaniaGARCIALEAL_3_09022021